<html>
<head>
<LINK rel="stylesheet" href="style.css" type="text/css">
<title>Organic Mechanisms Online</title>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">
<table width="100%" cellpadding="0" cellspacing="0"><tr class="tit"><td width="80%" align="left"><a href="index.php"><img src="title.gif" border="0"></a></td><td width="20%" class="detail" align="center"><table><tr><td>
</b></font></td></tr><tr><td>
<a href="http://www.formatdesign.co.uk" target="new"><img src="author.gif" border="0"></a></td></tr></table></td></tr></table><table width="100%" cellpadding="0" cellspacing="0"><tr class="search"><td width="100%" align="right" valign="middle" height="22"><form style="display: inline; margin: 0;" action="search.php" method="post"><input type="text" name="Search" size="15"><input type="submit" value="Search">&nbsp &nbsp</form></td></tr></table></td></tr></table>
<table width="100%" cellpadding="0" cellspacing="5" border="0">
<tr><td> &nbsp &nbsp </td><td width="205"  valign="top">

<table width="205" cellpadding="0" cellspacing="0"><tr><td height="30"></td></tr>


<tr class="gap"><td width="100%" valign="left" class="clicked"><img src="line.gif"></td></tr>
<tr><td valign="left"><img src="arrow.gif" border="0"> &nbsp <a href="Year.php?&Year=First" class="link">First year mechanisms</a></td></tr><tr class="gap"><td width="100%"><img src="line.gif"></td></tr>
<tr><td valign="left"><img src="arrow.gif" border="0"> &nbsp <a href="Year.php?&Year=Second" class="link">Second year mechanisms</a></td></tr>
<tr class="gap"><td width="100%"><img src="line.gif"></td></tr>
<tr><td valign="left"><img src="arrow.gif" border="0"> &nbsp <a href="Year.php?&Year=Third" class="link">Third year mechanisms</a></td></tr>
<tr class="gap"><td width="100%"><img src="line.gif"></td></tr>
<tr><td valign="left"><img src="arrow.gif" border="0"> &nbsp <a href="All.php?" class="link">All mechanisms</a></td></tr>
<tr class="gap"><td width="100%"><img src="line.gif"></td></tr>
<tr><td valign="left"><img src="arrow.gif" border="0"> &nbsp <a href="book.php" class="link">Books</a></td></tr>
<tr class="gap"><td width="100%"><img src="line.gif"></td></tr>
</table>

</td>
<td> &nbsp &nbsp &nbsp  </td><td> &nbsp</td><td> &nbsp</td>
<td width="100%" class="main" valign="top"><br>

<h3>General organic chemistry</h3>
<table cellspacing="10">
<tr><td><a href="http://www.amazon.co.uk/gp/product/0632058161?ie=UTF8&tag=4college-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0632058161"><img border="0" src="41dMVjozKFL._SL160_.jpg"></a><img src="http://www.assoc-amazon.co.uk/e/ir?t=4college-21&l=as2&o=2&a=0632058161" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
</td><td valign="top"><a href="http://www.amazon.co.uk/gp/product/0632058161?ie=UTF8&tag=4college-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0632058161">Keynotes in Organic Chemistry</a><img src="http://www.assoc-amazon.co.uk/e/ir?t=4college-21&l=as2&o=2&a=0632058161" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
<br><br>Excellent book for general organic chemistry. I found this book particularly useful for first year chemistry at Oxford. Provides useful summary of most of the fisrt
 year topics in organic chemistry, and is good for preparing written answers to descriptive questions.</td></tr> 
<tr><td>
<a href="http://www.amazon.co.uk/gp/redirect.html?ie=UTF8&location=https%3A%2F%2Fwww.amazon.co.uk%2Fs%3Fie%3DUTF8%26x%3D0%26ref_%3Dnb%255Fss%26y%3D0%26field-keywords%3Dorganic%2520oxford%2520chemistry%2520primers%26url%3Dsearch-alias%253Daps&tag=4college-21&linkCode=ur2&camp=1634&creative=19450"><img src="primers.jpg" border="0"></a><img src="https://www.assoc-amazon.co.uk/e/ir?t=4college-21&l=ur2&o=2" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
</td><td valign="top"><a href="http://www.amazon.co.uk/gp/redirect.html?ie=UTF8&location=https%3A%2F%2Fwww.amazon.co.uk%2Fs%3Fie%3DUTF8%26x%3D0%26ref_%3Dnb%255Fss%26y%3D0%26field-keywords%3Dorganic%2520oxford%2520chemistry%2520primers%26url%3Dsearch-alias%253Daps&tag=4college-21&linkCode=ur2&camp=1634&creative=19450">Oxford Chemistry Primers</a><img src="https://www.assoc-amazon.co.uk/e/ir?t=4college-21&l=ur2&o=2" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
<br><br>Written by Oxford lecturers, these books are excellent for learning any organic topic in detail.</td></tr>
<tr><td><a href="http://www.amazon.co.uk/gp/product/0198503466?ie=UTF8&tag=4college-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0198503466"><img border="0" src="511Y3H75BQL._SL110_.jpg"></a><img src="http://www.assoc-amazon.co.uk/e/ir?t=4college-21&l=as2&o=2&a=0198503466" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
</td><td valign="top">
<a href="http://www.amazon.co.uk/gp/product/0198503466?ie=UTF8&tag=4college-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0198503466">Organic Chemistry</a><img src="http://www.assoc-amazon.co.uk/e/ir?t=4college-21&l=as2&o=2&a=0198503466" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
<br><br>Essential book for any Undergraduate Chemist.</td></tr>
<tr><td colspan="2"><br>
<h3>Specific topics</h3>
</td></tr>
<tr><td><a href="http://www.amazon.co.uk/gp/product/0632052929?ie=UTF8&tag=4college-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0632052929"><img border="0" src="41D31RMVWML._SL160_.jpg"></a><img src="http://www.assoc-amazon.co.uk/e/ir?t=4college-21&l=as2&o=2&a=0632052929" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
</td><td valign="top"><a href="http://www.amazon.co.uk/gp/product/0632052929?ie=UTF8&tag=4college-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0632052929">An Introduction to Free-radical Chemistry</a><img src="http://www.assoc-amazon.co.uk/e/ir?t=4college-21&l=as2&o=2&a=0632052929" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
<br><br>Very good book for free radicals.</td></tr>
<tr><td><a href="http://www.amazon.co.uk/gp/product/0470712368?ie=UTF8&tag=4college-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0470712368"><img border="0" src="51OpdRswd0L._SL160_.jpg"></a><img src="http://www.assoc-amazon.co.uk/e/ir?t=4college-21&l=as2&o=2&a=0470712368" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
</td><td valign="top"><a href="http://www.amazon.co.uk/gp/product/0470712368?ie=UTF8&tag=4college-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0470712368">Organic Synthesis: The Disconnection Approach</a><img src="http://www.assoc-amazon.co.uk/e/ir?t=4college-21&l=as2&o=2&a=0470712368" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
<br><br>Excellent for retrosynthetic analysis.</td></tr>
</table>










</table>





</body></html>