<html>
<head>
<LINK rel="stylesheet" href="style.css" type="text/css">
<title>Organic Mechanisms Online</title>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">
<table width="100%" cellpadding="0" cellspacing="0"><tr class="tit"><td width="80%" align="left"><a href="index.php"><img src="title.gif" border="0"></a></td><td width="20%" class="detail" align="center"><table><tr><td>
</b></font></td></tr><tr><td>

<a href="http://www.formatdesign.co.uk" target="new"><img src="author.gif" border="0"></a></td></tr></table></td></tr></table><table width="100%" cellpadding="0" cellspacing="0"><tr class="search"><td width="100%" align="right" valign="middle" height="22"><form style="display: inline; margin: 0;" action="search.php" method="post"><input type="text" name="Search" size="15"><input type="submit" value="Search">&nbsp &nbsp</form></td></tr></table></td></tr></table>
<table width="100%" cellpadding="0" cellspacing="5" border="0">
<tr><td> &nbsp &nbsp </td><td width="205" valign="top">

<table width="205" cellpadding="0" cellspacing="0"><tr><td height="30"></td></tr>



<tr class="gap"><td width="100%" valign="left" class="clicked"><img src="line.gif"></td></tr>
<tr><td valign="left"><img src="arrow.gif" border="0"> &nbsp <a href="Year.php?&Year=First" class="link">First year mechanisms</a></td></tr><tr class="gap"><td width="100%"><img src="line.gif"></td></tr>
<tr><td valign="left"><img src="arrow.gif" border="0"> &nbsp <a href="Year.php?&Year=Second" class="link">Second year mechanisms</a></td></tr>
<tr class="gap"><td width="100%"><img src="line.gif"></td></tr>
<tr><td valign="left"><img src="arrow.gif" border="0"> &nbsp <a href="Year.php?&Year=Third" class="link">Third year mechanisms</a></td></tr>
<tr class="gap"><td width="100%"><img src="line.gif"></td></tr>
<tr><td valign="left"><img src="arrow.gif" border="0"> &nbsp <a href="All.php?" class="link">All mechanisms</a></td></tr>
<tr class="gap"><td width="100%"><img src="line.gif"></td></tr>
<tr><td valign="left"><img src="arrow.gif" border="0"> &nbsp <a href="book.php" class="link">Books</a></td></tr>
<tr class="gap"><td width="100%"><img src="line.gif"></td></tr>


</table>

</td>
<td> &nbsp &nbsp &nbsp  </td><td> &nbsp</td><td> &nbsp</td>
<td width="100%" class="main" valign="top" align="center"><br>
<br>
<table>
<tr><td colspan="5"><h3>Phosphorous- Wittig- intramolecular</h3></td></tr><tr><td colspan="5" width="300" ><center><img src="Files/Phosphorous- Wittig- intramolecular.gif" ></td></tr></table>



</td></tr>
</table>




</body></html>